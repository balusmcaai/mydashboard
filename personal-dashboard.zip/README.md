# Personal Dashboard

A simple personal dashboard with To-Do, Quote, and Clock widgets built using React + TailwindCSS.
